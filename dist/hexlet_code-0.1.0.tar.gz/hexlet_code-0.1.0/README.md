### Hexlet tests and linter status:
[![Actions Status](https://github.com/Oxana-Shu/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Oxana-Shu/python-project-49/actions)

Выполнение шага 5 в проекте Игры разума:
![](https://github.com/Oxana-Shu/python-project-49/blob/main/brain-even.gif)

Выполнение шага 6 в проекте Игры разума:
![](https://github.com/Oxana-Shu/python-project-49/blob/main/brain-calc.gif)

Выполнение шага 7 в проекте Игры разума:
![](https://github.com/Oxana-Shu/python-project-49/blob/main/brain-gcd.gif)
