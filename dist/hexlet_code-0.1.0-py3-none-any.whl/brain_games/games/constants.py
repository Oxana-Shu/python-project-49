CALC_MESSAGE_START = 'What is the result of the expression?'
EVEN_MESSAGE_START = 'Answer "yes" if the number is even, otherwise answer "no".'
GCD_MESSAGE_START = 'Find the greatest common divisor of given numbers.'
PRIME_MESSAGE_START = 'Answer "yes" if given number is prime. Otherwise answer "no".'
PROGRESSION_MESSAGE_START = 'What number is missing in the progression?'
TRUE_ANSWERS_COUNT = 3