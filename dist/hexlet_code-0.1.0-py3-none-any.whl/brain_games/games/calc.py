from brain_games.games import engine
from brain_games.games import constants


def calc_game():
    name = engine.user_interaction('welcome')
    print(constants.CALC_MESSAGE_START)
    for i in range(constants.COUNTS_ROUND):
        true_answer = get_math_question_and_result()
        user_answer = engine.user_interaction('answer')
        if user_answer == str(true_answer):
            engine.correct_answer()
            i += 1
        else:
            engine.wrong_answer(name, user_answer, true_answer)
            return
    engine.congratulations(name)


def get_math_question_and_result():
    first_num = engine.get_random_number(1, 100)
    second_num = engine.get_random_number(1, 100)
    random_operation = engine.get_random_number(1, 3)
    match random_operation:
        case 1:
            example = (
                f'Question: {first_num} + {second_num}',
                first_num + second_num
            )
        case 2:
            example = (
                f'Question: {first_num} - {second_num}',
                first_num - second_num
            )
        case _:
            example = (
                f'Question: {first_num} * {second_num}',
                first_num * second_num
            )
    print(example[0])

    return example[1]

